import { NSL_FAMILIES, NSL_FEATURES, NSL_ROWS } from "./nsl-sample";
import { mulberry32, randn, shuffle } from "./rng";

export type Family = "normal" | "dos" | "probe" | "r2l" | "u2r";
export type DatasetId = "nsl-kdd" | "cicids2017" | "unsw-nb15";

export type Row = {
  x: number[];
  y: 0 | 1;
  family: Family;
};

export type DatasetInfo = {
  id: DatasetId;
  name: string;
  kind: "recorded" | "scenario";
  origin: string;
  summary: string;
  features: readonly string[];
};

const CIC_FEATURES = [
  "flow_duration",
  "tot_fwd_pkts",
  "tot_bwd_pkts",
  "flow_byts_s",
  "flow_pkts_s",
  "pkt_len_mean",
  "flow_iat_mean",
  "syn_flag",
  "ack_flag",
  "fwd_init_win",
  "bwd_init_win",
  "idle_mean",
] as const;

const UNSW_FEATURES = [
  "dur",
  "spkts",
  "dpkts",
  "sbytes",
  "dbytes",
  "rate",
  "sttl",
  "sload",
  "dload",
  "sinpkt",
  "ct_srv_src",
  "ct_state_ttl",
] as const;

export const DATASETS: DatasetInfo[] = [
  {
    id: "nsl-kdd",
    name: "NSL-KDD",
    kind: "recorded",
    origin: "KDDTrain+ · University of New Brunswick",
    summary:
      "Stratified subsample of the real KDDTrain+ file: 720 normal, 480 DoS, 300 probe, 220 R2L, and all 52 U2R rows. Bytes and counts are scaled into [0, 1]; rates are unchanged.",
    features: NSL_FEATURES,
  },
  {
    id: "cicids2017",
    name: "CICIDS2017",
    kind: "scenario",
    origin: "Flow-feature scenario · CIC schema",
    summary:
      "Class-conditional flows on the CICIDS2017 numeric schema (duration, packet counts, SYN/ACK, window sizes). Same pipeline as NSL-KDD, harder overlap, so the bench is not tuned to one file.",
    features: CIC_FEATURES,
  },
  {
    id: "unsw-nb15",
    name: "UNSW-NB15",
    kind: "scenario",
    origin: "Flow-feature scenario · UNSW schema",
    summary:
      "Class-conditional flows on the UNSW-NB15 schema (rate, TTL, load, connection counts). Used to check that the defense is not an NSL-KDD-only trick.",
    features: UNSW_FEATURES,
  },
];

type Profile = { family: Family; mean: number[]; weight: number };

function scenario(
  seed: number,
  features: readonly string[],
  std: number,
  profiles: Profile[],
  n: number,
): Row[] {
  const rng = mulberry32(seed);
  const weightSum = profiles.reduce((s, p) => s + p.weight, 0);
  const rows: Row[] = [];
  for (let i = 0; i < n; i++) {
    let pick = rng() * weightSum;
    let profile = profiles[0] as Profile;
    for (const candidate of profiles) {
      pick -= candidate.weight;
      if (pick <= 0) {
        profile = candidate;
        break;
      }
    }
    const x = profile.mean.map((m) => {
      const v = m + randn(rng) * std;
      return Math.max(0, Math.min(1, Math.round(v * 1000) / 1000));
    });
    rows.push({
      x,
      y: profile.family === "normal" ? 0 : 1,
      family: profile.family,
    });
  }
  return rows;
}

const cicProfiles: Profile[] = [
  {
    family: "normal",
    weight: 0.5,
    mean: [0.22, 0.28, 0.36, 0.34, 0.22, 0.48, 0.3, 0.08, 0.72, 0.55, 0.5, 0.18],
  },
  {
    family: "dos",
    weight: 0.24,
    mean: [0.08, 0.86, 0.12, 0.1, 0.9, 0.14, 0.08, 0.88, 0.16, 0.2, 0.12, 0.06],
  },
  {
    family: "probe",
    weight: 0.16,
    mean: [0.3, 0.22, 0.1, 0.12, 0.48, 0.16, 0.2, 0.62, 0.22, 0.28, 0.18, 0.1],
  },
  {
    family: "r2l",
    weight: 0.1,
    mean: [0.46, 0.18, 0.2, 0.22, 0.16, 0.26, 0.42, 0.14, 0.58, 0.4, 0.36, 0.28],
  },
];

const unswProfiles: Profile[] = [
  {
    family: "normal",
    weight: 0.52,
    mean: [0.2, 0.3, 0.34, 0.4, 0.46, 0.18, 0.22, 0.28, 0.42, 0.36, 0.24, 0.12],
  },
  {
    family: "dos",
    weight: 0.22,
    mean: [0.06, 0.78, 0.1, 0.12, 0.08, 0.9, 0.84, 0.2, 0.06, 0.08, 0.82, 0.7],
  },
  {
    family: "probe",
    weight: 0.16,
    mean: [0.18, 0.24, 0.12, 0.16, 0.1, 0.55, 0.48, 0.16, 0.1, 0.14, 0.7, 0.36],
  },
  {
    family: "r2l",
    weight: 0.1,
    mean: [0.42, 0.16, 0.18, 0.28, 0.2, 0.14, 0.3, 0.22, 0.18, 0.4, 0.28, 0.22],
  },
];

function nslRows(): Row[] {
  return NSL_ROWS.map((row) => {
    const family = NSL_FAMILIES[row[0] ?? 0] ?? "normal";
    return {
      x: row.slice(1),
      y: family === "normal" ? 0 : 1,
      family,
    };
  });
}

const scenarioCache = new Map<string, Row[]>();

export function loadRows(id: DatasetId, seed: number, limit: number): Row[] {
  if (id === "nsl-kdd") {
    const copy = nslRows();
    shuffle(copy, mulberry32(seed));
    return copy.slice(0, Math.min(limit, copy.length));
  }
  const info = DATASETS.find((d) => d.id === id);
  const features = info?.features ?? CIC_FEATURES;
  const key = `${id}:${seed}:full`;
  let full = scenarioCache.get(key);
  if (!full) {
    full =
      id === "cicids2017"
        ? scenario(seed + 17, features, 0.13, cicProfiles, 1600)
        : scenario(seed + 41, features, 0.12, unswProfiles, 1600);
    scenarioCache.set(key, full);
  }
  const copy = full.slice();
  shuffle(copy, mulberry32(seed + 99));
  return copy.slice(0, Math.min(limit, copy.length));
}

export function datasetInfo(id: DatasetId): DatasetInfo {
  return DATASETS.find((d) => d.id === id) ?? DATASETS[0];
}

export function featureNames(id: DatasetId): readonly string[] {
  return datasetInfo(id).features;
}
