import { bestThreshold } from "./metrics";
import { shuffle } from "./rng";

export type MLP = {
  d: number;
  h: number;
  W1: number[][];
  b1: number[];
  W2: number[];
  b2: number;
  threshold: number;
};

export type SVM = {
  w: number[];
  b: number;
  threshold: number;
};

type TreeNode =
  | { leaf: true; p: number }
  | { leaf: false; feature: number; thr: number; left: TreeNode; right: TreeNode };

export type Forest = {
  trees: TreeNode[];
  threshold: number;
};

function gini(p: number): number {
  return 2 * p * (1 - p);
}

function meanLabel(y: number[], idxs: number[]): number {
  let s = 0;
  for (const i of idxs) s += y[i] ?? 0;
  return s / Math.max(1, idxs.length);
}

export function trainForest(
  X: number[][],
  y: number[],
  rng: () => number,
  trees = 11,
  maxDepth = 8,
  minLeaf = 6,
): Forest {
  const n = X.length;
  const d = X[0]?.length ?? 0;
  const nFeats = Math.max(3, Math.round(Math.sqrt(d)));
  const built: TreeNode[] = [];

  function build(idxs: number[], depth: number): TreeNode {
    const p = meanLabel(y, idxs);
    if (depth >= maxDepth || idxs.length <= minLeaf || p <= 0.001 || p >= 0.999) {
      return { leaf: true, p };
    }
    const parent = gini(p);
    const featOrder = Array.from({ length: d }, (_, i) => i);
    shuffle(featOrder, rng);
    const feats = featOrder.slice(0, nFeats);
    let bestGain = 1e-8;
    let bestFeat = -1;
    let bestThr = 0;
    let bestLeft: number[] = [];
    let bestRight: number[] = [];

    for (const f of feats) {
      const values: number[] = [];
      for (const i of idxs) values.push(X[i]?.[f] ?? 0);
      values.sort((a, b) => a - b);
      for (let q = 1; q <= 6; q++) {
        const thr = values[Math.floor((q / 7) * (values.length - 1))] ?? 0;
        const left: number[] = [];
        const right: number[] = [];
        for (const i of idxs) {
          if ((X[i]?.[f] ?? 0) <= thr) left.push(i);
          else right.push(i);
        }
        if (left.length < minLeaf || right.length < minLeaf) continue;
        const pL = meanLabel(y, left);
        const pR = meanLabel(y, right);
        const gain = parent - (left.length / idxs.length) * gini(pL) - (right.length / idxs.length) * gini(pR);
        if (gain > bestGain) {
          bestGain = gain;
          bestFeat = f;
          bestThr = thr;
          bestLeft = left;
          bestRight = right;
        }
      }
    }
    if (bestFeat < 0) return { leaf: true, p };
    return {
      leaf: false,
      feature: bestFeat,
      thr: bestThr,
      left: build(bestLeft, depth + 1),
      right: build(bestRight, depth + 1),
    };
  }

  for (let t = 0; t < trees; t++) {
    const boot: number[] = [];
    for (let i = 0; i < n; i++) boot.push(Math.floor(rng() * n));
    built.push(build(boot, 0));
  }

  const scores = X.map((row) => forestScore(built, row));
  return { trees: built, threshold: bestThreshold(scores, y) };
}

function treeScore(node: TreeNode, x: number[]): number {
  let cur = node;
  while (!cur.leaf) {
    cur = (x[cur.feature] ?? 0) <= cur.thr ? cur.left : cur.right;
  }
  return cur.p;
}

function forestScore(trees: TreeNode[], x: number[]): number {
  let s = 0;
  for (const tree of trees) s += treeScore(tree, x);
  return s / Math.max(1, trees.length);
}

export function predictForest(model: Forest, x: number[]): { score: number; label: 0 | 1 } {
  const score = forestScore(model.trees, x);
  return { score, label: score >= model.threshold ? 1 : 0 };
}

export function trainSVM(X: number[][], y: number[], rng: () => number, epochs = 18, lr = 0.08): SVM {
  const d = X[0]?.length ?? 0;
  const w = Array.from({ length: d }, () => (rng() - 0.5) * 0.05);
  let b = 0;
  const l2 = 0.002;
  const order = X.map((_, i) => i);
  const signed = y.map((v) => (v === 1 ? 1 : -1));

  for (let ep = 0; ep < epochs; ep++) {
    shuffle(order, rng);
    for (const i of order) {
      const x = X[i] as number[];
      const yi = signed[i] ?? 1;
      let margin = b;
      for (let j = 0; j < d; j++) margin += w[j] * (x[j] ?? 0);
      margin *= yi;
      if (margin < 1) {
        for (let j = 0; j < d; j++) w[j] += lr * (yi * (x[j] ?? 0) - l2 * w[j]);
        b += lr * yi;
      } else {
        for (let j = 0; j < d; j++) w[j] -= lr * l2 * w[j];
      }
    }
  }
  const scores = X.map((row) => svmRaw(w, b, row));
  return { w, b, threshold: bestThreshold(scores, y) };
}

function svmRaw(w: number[], b: number, x: number[]): number {
  let s = b;
  for (let j = 0; j < w.length; j++) s += w[j] * (x[j] ?? 0);
  return s;
}

export function predictSVM(model: SVM, x: number[]): { score: number; label: 0 | 1 } {
  const score = svmRaw(model.w, model.b, x);
  return { score, label: score >= model.threshold ? 1 : 0 };
}

function clipSigmoid(z: number): number {
  const c = Math.max(-25, Math.min(25, z));
  return 1 / (1 + Math.exp(-c));
}

export function createMLP(d: number, h: number, rng: () => number): MLP {
  const scale = Math.sqrt(2 / d);
  const W1 = Array.from({ length: d }, () =>
    Array.from({ length: h }, () => (rng() * 2 - 1) * scale),
  );
  const b1 = Array.from({ length: h }, () => 0);
  const outScale = Math.sqrt(2 / h);
  const W2 = Array.from({ length: h }, () => (rng() * 2 - 1) * outScale);
  return { d, h, W1, b1, W2, b2: 0, threshold: 0.5 };
}

export function cloneMLP(m: MLP): MLP {
  return {
    d: m.d,
    h: m.h,
    W1: m.W1.map((row) => row.slice()),
    b1: m.b1.slice(),
    W2: m.W2.slice(),
    b2: m.b2,
    threshold: m.threshold,
  };
}

type Cache = { z1: number[]; a1: number[]; z2: number; p: number };

function forward(m: MLP, x: number[]): Cache {
  const z1 = new Array<number>(m.h);
  const a1 = new Array<number>(m.h);
  for (let j = 0; j < m.h; j++) {
    let s = m.b1[j] ?? 0;
    for (let i = 0; i < m.d; i++) s += (x[i] ?? 0) * (m.W1[i]?.[j] ?? 0);
    z1[j] = s;
    a1[j] = s > 0 ? s : 0;
  }
  let z2 = m.b2;
  for (let j = 0; j < m.h; j++) z2 += (a1[j] ?? 0) * (m.W2[j] ?? 0);
  return { z1, a1, z2, p: clipSigmoid(z2) };
}

/** Gradient of the attack logit w.r.t. input. Non-vanishing, unlike saturated BCE. */
export function logitGradX(m: MLP, x: number[]): number[] {
  const { z1 } = forward(m, x);
  const dx = new Array<number>(m.d).fill(0);
  for (let j = 0; j < m.h; j++) {
    if ((z1[j] ?? 0) <= 0) continue;
    const back = m.W2[j] ?? 0;
    for (let i = 0; i < m.d; i++) dx[i] += (m.W1[i]?.[j] ?? 0) * back;
  }
  return dx;
}

type Adam = { m: number; v: number };

function adamUpdate(param: number, g: number, slot: Adam, t: number, lr: number): number {
  slot.m = 0.9 * slot.m + 0.1 * g;
  slot.v = 0.999 * slot.v + 0.001 * g * g;
  const mh = slot.m / (1 - 0.9 ** t);
  const vh = slot.v / (1 - 0.999 ** t);
  return param - (lr * mh) / (Math.sqrt(vh) + 1e-8);
}

export function sgdMLP(m: MLP, X: number[][], y: number[], lr: number, t0: number): number {
  const dW1 = m.W1.map((row) => row.map(() => 0));
  const db1 = m.b1.map(() => 0);
  const dW2 = m.W2.map(() => 0);
  let db2 = 0;
  const n = X.length;
  for (let s = 0; s < n; s++) {
    const x = X[s] as number[];
    const cache = forward(m, x);
    const dz2 = cache.p - (y[s] ?? 0);
    db2 += dz2;
    for (let j = 0; j < m.h; j++) {
      dW2[j] += (cache.a1[j] ?? 0) * dz2;
      const da = (cache.z1[j] ?? 0) > 0 ? dz2 * (m.W2[j] ?? 0) : 0;
      db1[j] += da;
      for (let i = 0; i < m.d; i++) dW1[i][j] += (x[i] ?? 0) * da;
    }
  }
  const inv = 1 / Math.max(1, n);
  const slots = ensureAdam(m);
  let t = t0;
  t += 1;
  for (let i = 0; i < m.d; i++) {
    for (let j = 0; j < m.h; j++) {
      const id = i * m.h + j;
      m.W1[i][j] = adamUpdate(m.W1[i][j] ?? 0, (dW1[i]?.[j] ?? 0) * inv, slots.W1[id] as Adam, t, lr);
    }
  }
  for (let j = 0; j < m.h; j++) {
    m.b1[j] = adamUpdate(m.b1[j] ?? 0, (db1[j] ?? 0) * inv, slots.b1[j] as Adam, t, lr);
    m.W2[j] = adamUpdate(m.W2[j] ?? 0, (dW2[j] ?? 0) * inv, slots.W2[j] as Adam, t, lr);
  }
  m.b2 = adamUpdate(m.b2, db2 * inv, slots.b2, t, lr);
  return t;
}

type AdamPack = { W1: Adam[]; b1: Adam[]; W2: Adam[]; b2: Adam };

const adamMap = new WeakMap<MLP, AdamPack>();

function ensureAdam(m: MLP): AdamPack {
  let pack = adamMap.get(m);
  if (pack) return pack;
  const zero = (): Adam => ({ m: 0, v: 0 });
  pack = {
    W1: Array.from({ length: m.d * m.h }, zero),
    b1: Array.from({ length: m.h }, zero),
    W2: Array.from({ length: m.h }, zero),
    b2: zero(),
  };
  adamMap.set(m, pack);
  return pack;
}

export function trainMLP(
  X: number[][],
  y: number[],
  rng: () => number,
  epochs = 24,
  lr = 0.03,
  hidden = 24,
  batch = 64,
): MLP {
  const d = X[0]?.length ?? 0;
  const m = createMLP(d, hidden, rng);
  const order = X.map((_, i) => i);
  let t = 0;
  for (let ep = 0; ep < epochs; ep++) {
    shuffle(order, rng);
    for (let start = 0; start < order.length; start += batch) {
      const ids = order.slice(start, start + batch);
      const xb = ids.map((i) => X[i] as number[]);
      const yb = ids.map((i) => y[i] ?? 0);
      t = sgdMLP(m, xb, yb, lr, t);
    }
  }
  const scores = X.map((row) => forward(m, row).p);
  m.threshold = bestThreshold(scores, y);
  return m;
}

export function predictMLP(m: MLP, x: number[]): { score: number; label: 0 | 1 } {
  const score = forward(m, x).p;
  return { score, label: score >= m.threshold ? 1 : 0 };
}

export function retuneMLP(m: MLP, X: number[][], y: number[]): void {
  const scores = X.map((row) => forward(m, row).p);
  m.threshold = bestThreshold(scores, y);
}

export type Sanitizer = { lo: number[]; hi: number[]; step: number };

export function fitSanitizer(X: number[][], step = 0.05): Sanitizer {
  const d = X[0]?.length ?? 0;
  const lo: number[] = [];
  const hi: number[] = [];
  for (let j = 0; j < d; j++) {
    const col = X.map((row) => row[j] ?? 0).sort((a, b) => a - b);
    lo.push(col[Math.floor(0.02 * (col.length - 1))] ?? 0);
    hi.push(col[Math.ceil(0.98 * (col.length - 1))] ?? 1);
  }
  return { lo, hi, step };
}

export function sanitize(x: number[], s: Sanitizer): number[] {
  const out = new Array<number>(x.length);
  for (let j = 0; j < x.length; j++) {
    const clipped = Math.min(s.hi[j] ?? 1, Math.max(s.lo[j] ?? 0, x[j] ?? 0));
    const q = Math.round(clipped / s.step) * s.step;
    out[j] = Math.max(0, Math.min(1, q));
  }
  return out;
}
