export type Confusion = {
  tp: number;
  tn: number;
  fp: number;
  fn: number;
  accuracy: number;
  precision: number;
  recall: number;
  f1: number;
  fpr: number;
};

export function confusion(yTrue: number[], yPred: number[]): Confusion {
  let tp = 0;
  let tn = 0;
  let fp = 0;
  let fn = 0;
  for (let i = 0; i < yTrue.length; i++) {
    const y = yTrue[i];
    const p = yPred[i];
    if (y === 1 && p === 1) tp++;
    else if (y === 0 && p === 0) tn++;
    else if (y === 0 && p === 1) fp++;
    else fn++;
  }
  const accuracy = (tp + tn) / Math.max(1, yTrue.length);
  const precision = tp / Math.max(1, tp + fp);
  const recall = tp / Math.max(1, tp + fn);
  const f1 = precision + recall === 0 ? 0 : (2 * precision * recall) / (precision + recall);
  const fpr = fp / Math.max(1, fp + tn);
  return { tp, tn, fp, fn, accuracy, precision, recall, f1, fpr };
}

/** Share of clean detections that the attack flips to benign. */
export function attackSuccess(yTrue: number[], cleanPred: number[], advPred: number[]): number {
  let held = 0;
  let flipped = 0;
  for (let i = 0; i < yTrue.length; i++) {
    if (yTrue[i] !== 1 || cleanPred[i] !== 1) continue;
    held++;
    if (advPred[i] === 0) flipped++;
  }
  return held === 0 ? 0 : flipped / held;
}

/** Train-only threshold. Sweeps score quantiles so it works for probabilities and raw margins. */
export function bestThreshold(scores: number[], y: number[]): number {
  if (scores.length === 0) return 0.5;
  const sorted = scores.slice().sort((a, b) => a - b);
  let bestT = sorted[Math.floor(sorted.length / 2)] ?? 0.5;
  let bestF1 = -1;
  for (let s = 0; s <= 24; s++) {
    const idx = Math.min(sorted.length - 1, Math.floor((s / 24) * (sorted.length - 1)));
    const t = sorted[idx] ?? 0.5;
    const pred = scores.map((value) => (value >= t ? 1 : 0));
    const f1 = confusion(y, pred).f1;
    if (f1 > bestF1) {
      bestF1 = f1;
      bestT = t;
    }
  }
  return bestT;
}

/**
 * AdversarialShield Robustness Score.
 * Weighted retention of clean F1 across increasing L∞ budgets.
 * Weights put more mass on stronger attacks. Capped at 1.
 */
export const ASRS_EPS = [0.05, 0.1, 0.2, 0.3] as const;
export const ASRS_WEIGHTS = [0.1, 0.2, 0.3, 0.4] as const;

export function asrs(cleanF1: number, f1AtEps: number[]): number {
  const base = Math.max(cleanF1, 1e-6);
  let score = 0;
  for (let i = 0; i < ASRS_WEIGHTS.length; i++) {
    const ratio = Math.min(1, (f1AtEps[i] ?? 0) / base);
    score += ASRS_WEIGHTS[i] * ratio;
  }
  return score;
}
