import { logitGradX, sanitize, type MLP, type SVM, type Sanitizer } from "./models";

function clip(v: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, v));
}

function sign(v: number): number {
  if (v > 1e-12) return 1;
  if (v < -1e-12) return -1;
  return 0;
}

/** Direction that decreases P(attack). Components in {-1, 0, 1}. */
export function dnnDirection(m: MLP, x: number[]): number[] {
  const g = logitGradX(m, x);
  return g.map((v) => -sign(v));
}

export function svmDirection(model: SVM): number[] {
  return model.w.map((v) => -sign(v));
}

export function combinedDirection(dnn: MLP, svm: SVM, x: number[]): number[] {
  const gd = dnnDirection(dnn, x);
  const gs = svmDirection(svm);
  return gd.map((d, i) => sign(d + (gs[i] ?? 0)));
}

export type AttackKind = "fgsm" | "pgd";

/**
 * L∞ evasion on intrusion rows only. Benign rows are copied.
 * When `adaptive` is set, gradients are taken at the sanitized point
 * (straight-through), matching an attacker who knows the squeeze defense.
 */
export function craftAttack(
  X: number[][],
  y: number[],
  kind: AttackKind,
  epsilon: number,
  steps: number,
  directionAt: (x: number[]) => number[],
  sanitizer: Sanitizer | null,
): number[][] {
  const nSteps = kind === "fgsm" ? 1 : Math.max(1, steps);
  const alpha = kind === "fgsm" ? epsilon : Math.max(epsilon / nSteps, epsilon * 0.35);
  return X.map((x0, i) => {
    if ((y[i] ?? 0) !== 1 || epsilon <= 0) return x0.slice();
    let x = x0.map((v, k) => clip(v + ((((k * 13) % 5) - 2) / 2) * epsilon * 0.25, 0, 1));
    for (let s = 0; s < nSteps; s++) {
      const seen = sanitizer ? sanitize(x, sanitizer) : x;
      const dir = directionAt(seen);
      const next = new Array<number>(x.length);
      for (let k = 0; k < x.length; k++) {
        const moved = x[k] + alpha * (dir[k] ?? 0);
        const lo = Math.max(0, (x0[k] ?? 0) - epsilon);
        const hi = Math.min(1, (x0[k] ?? 0) + epsilon);
        next[k] = clip(moved, lo, hi);
      }
      x = next;
    }
    return x;
  });
}
