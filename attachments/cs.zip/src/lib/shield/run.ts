import {
  combinedDirection,
  craftAttack,
  dnnDirection,
  svmDirection,
  type AttackKind,
} from "./attacks";
import { datasetInfo, loadRows, type DatasetId, type Family, type Row } from "./data";
import {
  ASRS_EPS,
  attackSuccess,
  asrs,
  confusion,
  type Confusion,
} from "./metrics";
import {
  cloneMLP,
  fitSanitizer,
  predictForest,
  predictMLP,
  predictSVM,
  retuneMLP,
  sanitize,
  sgdMLP,
  trainForest,
  trainMLP,
  trainSVM,
  type Forest,
  type MLP,
  type SVM,
  type Sanitizer,
} from "./models";
import { mulberry32, shuffle } from "./rng";

export type ModelId = "rf" | "svm" | "dnn" | "dnn-sq" | "at" | "ensemble" | "hybrid";

export type FamilyStat = {
  family: Family;
  support: number;
  clean: number;
  adv: number;
};

export type ModelScore = {
  id: ModelId;
  name: string;
  attack: string;
  clean: Confusion;
  adv: Confusion;
  asr: number;
  asrs: number;
  latencyMs: number;
  families: FamilyStat[];
};

export type FlowExample = {
  id: number;
  family: Family;
  y: 0 | 1;
  clean: 0 | 1;
  adv: 0 | 1;
  hybrid: 0 | 1;
  maxDelta: number;
  feature: string;
  delta: number;
};

export type SweepPoint = {
  epsilon: number;
  f1: Record<ModelId, number>;
};

export type TrainedBench = {
  datasetId: DatasetId;
  features: readonly string[];
  seed: number;
  trainN: number;
  testN: number;
  normalTest: number;
  attackTest: number;
  trainedMs: number;
  rf: Forest;
  svm: SVM;
  dnn: MLP;
  at: MLP;
  rfRobust: Forest;
  svmRobust: SVM;
  sanitizer: Sanitizer;
  testX: number[][];
  testY: number[];
  testFamily: Family[];
};

export type EvalOptions = {
  attack: AttackKind;
  epsilon: number;
  steps: number;
};

const MODEL_META: { id: ModelId; name: string; attack: string }[] = [
  { id: "rf", name: "Random forest", attack: "Transfer from the network" },
  { id: "svm", name: "Linear SVM", attack: "Optimal L∞ step on weights" },
  { id: "dnn", name: "Deep network", attack: "White-box logit PGD / FGSM" },
  { id: "dnn-sq", name: "Network + squeeze", attack: "Adaptive straight-through" },
  { id: "at", name: "Adversarial training", attack: "White-box on the robust net" },
  { id: "ensemble", name: "Ensemble vote", attack: "Joint network + SVM direction" },
  { id: "hybrid", name: "Hybrid shield", attack: "Adaptive attack on the defended committee" },
];

function splitRows(rows: Row[], testRatio: number, rng: () => number) {
  const groups = new Map<Family, Row[]>();
  for (const row of rows) {
    const list = groups.get(row.family) ?? [];
    list.push(row);
    groups.set(row.family, list);
  }
  const train: Row[] = [];
  const test: Row[] = [];
  for (const group of groups.values()) {
    shuffle(group, rng);
    const nTest = Math.max(1, Math.round(group.length * testRatio));
    test.push(...group.slice(0, nTest));
    train.push(...group.slice(nTest));
  }
  shuffle(train, rng);
  shuffle(test, rng);
  return { train, test };
}

const tick = () => new Promise<void>((resolve) => setTimeout(resolve, 0));

export async function trainBench(
  datasetId: DatasetId,
  seed: number,
  limit: number,
  onProgress?: (message: string) => void,
): Promise<TrainedBench> {
  const started = performance.now();
  const info = datasetInfo(datasetId);
  onProgress?.("Drawing a stratified train / test split");
  await tick();
  const rng = mulberry32(seed);
  const rows = loadRows(datasetId, seed, limit);
  const { train, test } = splitRows(rows, 0.3, rng);
  const X = train.map((row) => row.x);
  const y = train.map((row) => row.y);

  onProgress?.("Fitting the random forest");
  await tick();
  const rf = trainForest(X, y, rng, 11, 8, 5);

  onProgress?.("Fitting the linear SVM");
  await tick();
  const svm = trainSVM(X, y, rng, 16, 0.06);

  onProgress?.("Training the network on clean flows");
  await tick();
  const dnn = trainMLP(X, y, rng, 22, 0.035, 24, 64);

  onProgress?.("Adversarial training of the network, forest, and SVM");
  await tick();
  const at = cloneMLP(dnn);
  const trainEps = 0.15;
  const attackIds = y.map((label, index) => (label === 1 ? index : -1)).filter((index) => index >= 0);
  const seedAdv = craftAttack(
    attackIds.map((index) => X[index] as number[]),
    attackIds.map(() => 1),
    "pgd",
    trainEps,
    5,
    (point) => dnnDirection(dnn, point),
    null,
  );
  const Xaug = X.concat(seedAdv);
  const yaug = y.concat(attackIds.map(() => 1));
  const rfRobust = trainForest(Xaug, yaug, rng, 11, 8, 5);
  const svmRobust = trainSVM(Xaug, yaug, rng, 14, 0.06);

  const order = X.map((_, i) => i);
  let stepT = 0;
  for (let ep = 0; ep < 6; ep++) {
    shuffle(order, rng);
    for (let start = 0; start < order.length; start += 64) {
      const ids = order.slice(start, start + 64);
      const batchX: number[][] = [];
      const batchY: number[] = [];
      for (const i of ids) {
        const raw = X[i] as number[];
        const label = y[i] ?? 0;
        if (label === 1 && rng() < 0.75) {
          const crafted = craftAttack([raw], [1], "pgd", trainEps, 4, (point) => dnnDirection(at, point), null);
          batchX.push(crafted[0] as number[]);
        } else {
          batchX.push(raw);
        }
        batchY.push(label);
      }
      stepT = sgdMLP(at, batchX, batchY, 0.02, stepT);
    }
    if (ep % 2 === 1) await tick();
  }
  retuneMLP(at, X, y);

  onProgress?.("Fitting the feature squeeze on clean training ranges");
  await tick();
  const sanitizer = fitSanitizer(X, 0.02);

  const testX = test.map((row) => row.x);
  const testY = test.map((row) => row.y);
  return {
    datasetId,
    features: info.features,
    seed,
    trainN: train.length,
    testN: test.length,
    normalTest: testY.filter((label) => label === 0).length,
    attackTest: testY.filter((label) => label === 1).length,
    trainedMs: performance.now() - started,
    rf,
    svm,
    dnn,
    at,
    rfRobust,
    svmRobust,
    sanitizer,
    testX,
    testY,
    testFamily: test.map((row) => row.family),
  };
}

type Pred = 0 | 1;

function labelsOf(bench: TrainedBench, rows: number[][], id: ModelId): Pred[] {
  const out = new Array<Pred>(rows.length);
  for (let i = 0; i < rows.length; i++) {
    const raw = rows[i] as number[];
    const squeezed = sanitize(raw, bench.sanitizer);
    if (id === "rf") out[i] = predictForest(bench.rf, raw).label;
    else if (id === "svm") out[i] = predictSVM(bench.svm, raw).label;
    else if (id === "dnn") out[i] = predictMLP(bench.dnn, raw).label;
    else if (id === "dnn-sq") out[i] = predictMLP(bench.dnn, squeezed).label;
    else if (id === "at") out[i] = predictMLP(bench.at, raw).label;
    else if (id === "ensemble") {
      const votes =
        predictForest(bench.rf, raw).label +
        predictSVM(bench.svm, raw).label +
        predictMLP(bench.dnn, raw).label;
      out[i] = votes >= 2 ? 1 : 0;
    } else {
      const point = squeezed;
      const forest = predictForest(bench.rfRobust, point).label;
      const linear = predictSVM(bench.svmRobust, point).label;
      const robust = predictMLP(bench.at, point).label;
      // Two-key rule: trust the adversarially trained net, and also alert when
      // the defended forest and SVM agree an intrusion is present.
      out[i] = robust === 1 || (forest === 1 && linear === 1) ? 1 : 0;
    }
  }
  return out;
}

function attackRows(bench: TrainedBench, id: ModelId, opts: EvalOptions): number[][] {
  const adaptive = id === "dnn-sq" || id === "hybrid" ? bench.sanitizer : null;
  const direction =
    id === "svm"
      ? () => svmDirection(bench.svm)
      : id === "ensemble"
        ? (x: number[]) => combinedDirection(bench.dnn, bench.svm, x)
        : id === "hybrid"
          ? (x: number[]) => combinedDirection(bench.at, bench.svmRobust, x)
          : id === "at"
            ? (x: number[]) => dnnDirection(bench.at, x)
            : (x: number[]) => dnnDirection(bench.dnn, x);
  return craftAttack(bench.testX, bench.testY, opts.attack, opts.epsilon, opts.steps, direction, adaptive);
}

function familyStats(bench: TrainedBench, clean: Pred[], adv: Pred[]): FamilyStat[] {
  const families: Family[] = ["normal", "dos", "probe", "r2l", "u2r"];
  const stats: FamilyStat[] = [];
  for (const family of families) {
    const idx: number[] = [];
    for (let i = 0; i < bench.testFamily.length; i++) {
      if (bench.testFamily[i] === family) idx.push(i);
    }
    if (idx.length === 0) continue;
    if (family === "normal") {
      const rate = (pred: Pred[]) => idx.filter((i) => pred[i] === 1).length / idx.length;
      stats.push({ family, support: idx.length, clean: rate(clean), adv: rate(adv) });
    } else {
      const rate = (pred: Pred[]) => idx.filter((i) => pred[i] === 1).length / idx.length;
      stats.push({ family, support: idx.length, clean: rate(clean), adv: rate(adv) });
    }
  }
  return stats;
}

function scoreModel(bench: TrainedBench, id: ModelId, opts: EvalOptions, withAsrs: boolean): ModelScore {
  const meta = MODEL_META.find((item) => item.id === id) as (typeof MODEL_META)[number];
  const cleanPred = labelsOf(bench, bench.testX, id);
  const started = performance.now();
  const advX = attackRows(bench, id, opts);
  const advPred = labelsOf(bench, advX, id);
  const latencyMs = (performance.now() - started) / Math.max(1, bench.testN);
  let robust = 0;
  if (withAsrs) {
    const f1s = ASRS_EPS.map((epsilon) => {
      const attacked = attackRows(bench, id, { ...opts, epsilon });
      return confusion(bench.testY, labelsOf(bench, attacked, id)).f1;
    });
    robust = asrs(confusion(bench.testY, cleanPred).f1, f1s);
  }
  return {
    id,
    name: meta.name,
    attack: meta.attack,
    clean: confusion(bench.testY, cleanPred),
    adv: confusion(bench.testY, advPred),
    asr: attackSuccess(bench.testY, cleanPred, advPred),
    asrs: robust,
    latencyMs,
    families: familyStats(bench, cleanPred, advPred),
  };
}

export function evaluate(bench: TrainedBench, opts: EvalOptions, withAsrs = true): ModelScore[] {
  return MODEL_META.map((meta) => scoreModel(bench, meta.id, opts, withAsrs));
}

export function sweepCurve(bench: TrainedBench, attack: AttackKind, steps: number): SweepPoint[] {
  const epsilons = [0, 0.05, 0.1, 0.15, 0.2, 0.25, 0.3];
  return epsilons.map((epsilon) => {
    const f1 = {} as Record<ModelId, number>;
    for (const meta of MODEL_META) {
      if (epsilon === 0) {
        f1[meta.id] = confusion(bench.testY, labelsOf(bench, bench.testX, meta.id)).f1;
      } else {
        const advX = attackRows(bench, meta.id, { attack, epsilon, steps });
        f1[meta.id] = confusion(bench.testY, labelsOf(bench, advX, meta.id)).f1;
      }
    }
    return { epsilon, f1 };
  });
}

export function flowExamples(bench: TrainedBench, opts: EvalOptions): FlowExample[] {
  const dnnClean = labelsOf(bench, bench.testX, "dnn");
  const dnnAdvX = attackRows(bench, "dnn", opts);
  const dnnAdv = labelsOf(bench, dnnAdvX, "dnn");
  const hybridAdvX = attackRows(bench, "hybrid", opts);
  const hybridAdv = labelsOf(bench, hybridAdvX, "hybrid");
  const ranked = bench.testY
    .map((label, index) => ({ label, index }))
    .filter((item) => item.label === 1)
    .map((item) => {
      let maxDelta = 0;
      let feature = bench.features[0] ?? "feature";
      let delta = 0;
      const clean = bench.testX[item.index] as number[];
      const adv = dnnAdvX[item.index] as number[];
      for (let j = 0; j < clean.length; j++) {
        const change = Math.abs((adv[j] ?? 0) - (clean[j] ?? 0));
        if (change > maxDelta) {
          maxDelta = change;
          feature = bench.features[j] ?? feature;
          delta = (adv[j] ?? 0) - (clean[j] ?? 0);
        }
      }
      const flipped = dnnClean[item.index] === 1 && dnnAdv[item.index] === 0;
      return { ...item, maxDelta, feature, delta, flipped };
    })
    .sort((a, b) => Number(b.flipped) - Number(a.flipped) || b.maxDelta - a.maxDelta);

  return ranked.slice(0, 8).map((item) => ({
    id: item.index,
    family: bench.testFamily[item.index] ?? "dos",
    y: 1,
    clean: (dnnClean[item.index] ?? 0) as Pred,
    adv: (dnnAdv[item.index] ?? 0) as Pred,
    hybrid: (hybridAdv[item.index] ?? 0) as Pred,
    maxDelta: item.maxDelta,
    feature: item.feature,
    delta: item.delta,
  }));
}

export const MODEL_ORDER = MODEL_META;
